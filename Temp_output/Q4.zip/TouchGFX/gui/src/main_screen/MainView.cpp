#include <gui/main_screen/MainView.hpp>
#include <BitmapDatabase.hpp>
#include <cstring>

MainView::MainView()
{

}

void MainView::setupScreen()
{

}

void MainView::tearDownScreen()
{

}

void MainView::requestname()
{
  #ifndef SIMULATOR
    presenter->uart_transmit_request();
    memset(UserNameBuffer, 0, sizeof(UserNameBuffer));
    UserName.invalidate();
  #else
    touchgfx_printf("requestname\r\n");
  #endif
}


void MainView::set_UserNameBuffer(uint16_t* tBuff)
{
  #ifndef SIMULATOR
    Unicode::snprintf(UserNameBuffer, USERNAME_SIZE-2, "%s", tBuff);
    UserName.invalidate();
  #else
    touchgfx_printf("set_UserNameBuffer\r\n");
  #endif
}
