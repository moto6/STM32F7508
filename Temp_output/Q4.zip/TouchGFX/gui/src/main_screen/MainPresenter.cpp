#include <gui/main_screen/MainView.hpp>
#include <gui/main_screen/MainPresenter.hpp>

MainPresenter::MainPresenter(MainView& v)
    : view(v)
{
}

void MainPresenter::activate()
{
}

void MainPresenter::deactivate()
{
}

void MainPresenter::uart_transmit_request()
{
    model->uart_transmit_request();
}

void MainPresenter::uart_byte_received()
{
    view.set_UserNameBuffer(model->get_uart_recieve_buffer());
}