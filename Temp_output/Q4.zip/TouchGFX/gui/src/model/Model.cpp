#include <gui/model/Model.hpp>
#include <gui/model/ModelListener.hpp>
#include <cstring>

#ifndef SIMULATOR
#include "stm32f7xx_hal.h"
extern UART_HandleTypeDef huart1;
#endif

uint8_t str1[] = "\n\rEnter your Name : ";
uint8_t str2[] = "\b \b";

uint8_t str5[] = "\n\rHi your name is ";
uint8_t str6[] = "\n\r";

Model::Model() : modelListener(0)
{
}

void Model::tick()
{
#ifndef SIMULATOR
    if(HAL_UART_Receive(&huart1, &uart_receive_buffer, sizeof(uart_receive_buffer), 10) == HAL_OK)
    {
        if(uart_receive_buffer == 0x08 && rIndex > 0)
        {
            HAL_UART_Transmit(&huart1, str2, sizeof(str2), 10);
            inputBuffer[rIndex]=0;
            tempBuffer[--rIndex] = 0;
            modelListener->uart_byte_received();
        }
        else if(uart_receive_buffer == 0x0D && rIndex > 0)
        {
            HAL_UART_Transmit(&huart1, str5, sizeof(str5), 10);
            HAL_UART_Transmit(&huart1, inputBuffer, rIndex+1, 10);
            HAL_UART_Transmit(&huart1, str6, sizeof(str6), 10);
            init_tempBuffer();

            //modelListener->uart_byte_received();
        }
        else if(uart_receive_buffer>=0x20 && rIndex < 19)
        {
            HAL_UART_Transmit(&huart1, &uart_receive_buffer, sizeof(uart_receive_buffer), 10);
            tempBuffer[rIndex++] = uart_receive_buffer;
            inputBuffer[rIndex]=int8_t(uart_receive_buffer);
            inputBuffer[rIndex+1]=0;
            modelListener->uart_byte_received();
        }
    }
#endif
}

void Model::init_tempBuffer()
{
    rIndex = 0;
    memset(tempBuffer, 0, sizeof(tempBuffer));
    inputBuffer[0]=0;
    inputBuffer[1]=0;
}

void Model::uart_transmit_request()
{
#ifndef SIMULATOR
    HAL_UART_Transmit(&huart1, str1, sizeof(str1), 10);
#endif
    init_tempBuffer();
}