#include <stdint.h>
#include <touchgfx/Unicode.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif



// Language Gb: No substitution
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId2_Gb[12] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x55, 0x73, 0x65, 0x72, 0x20, 0x4e, 0x61, 0x6d, 0x65, 0x3a, 0x2, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId6_Gb[13] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x52, 0x65, 0x71, 0x75, 0x65, 0x73, 0x74, 0x20, 0x4e, 0x61, 0x6d, 0x65, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId9_Gb[9] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x4e, 0x65, 0x77, 0x20, 0x54, 0x65, 0x78, 0x74, 0x0 };

TEXT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::Unicode::UnicodeChar* const textsGb[5] TEXT_LOCATION_FLASH_ATTRIBUTE =
{
    T_SingleUseId2_Gb,
    T_SingleUseId6_Gb,
    T_SingleUseId9_Gb,
    T_SingleUseId9_Gb,
    T_SingleUseId9_Gb
};

