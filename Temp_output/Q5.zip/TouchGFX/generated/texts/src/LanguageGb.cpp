#include <stdint.h>
#include <touchgfx/Unicode.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif



// Language Gb: No substitution
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId3_Gb[7] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x4d, 0x69, 0x6e, 0x75, 0x74, 0x65, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId4_Gb[5] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x48, 0x6f, 0x75, 0x72, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId8_Gb[2] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x2, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId9_Gb[3] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x30, 0x30, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId14_Gb[13] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x43, 0x75, 0x72, 0x72, 0x6e, 0x65, 0x74, 0x20, 0x54, 0x49, 0x4d, 0x45, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId15_Gb[12] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x54, 0x61, 0x72, 0x67, 0x65, 0x74, 0x20, 0x54, 0x49, 0x4d, 0x45, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId16_Gb[7] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x54, 0x65, 0x6d, 0x70, 0x65, 0x72, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId17_Gb[10] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x41, 0x6c, 0x61, 0x72, 0x6d, 0x20, 0x54, 0x2f, 0x46, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId18_Gb[6] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x30, 0x30, 0x20, 0x27, 0x43, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId19_Gb[3] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x4f, 0x4e, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId20_Gb[4] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x4f, 0x46, 0x46, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId21_Gb[4] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x46, 0x41, 0x4e, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId22_Gb[7] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x4f, 0x70, 0x74, 0x69, 0x6f, 0x6e, 0x0 };
TEXT_LOCATION_FLASH_PRAGMA
KEEP const touchgfx::Unicode::UnicodeChar T_SingleUseId24_Gb[14] TEXT_LOCATION_FLASH_ATTRIBUTE = { 0x43, 0x6f, 0x6f, 0x6b, 0x69, 0x6e, 0x67, 0x20, 0x54, 0x69, 0x6d, 0x65, 0x72, 0x0 };

TEXT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::Unicode::UnicodeChar* const textsGb[22] TEXT_LOCATION_FLASH_ATTRIBUTE =
{
    T_SingleUseId8_Gb,
    T_SingleUseId8_Gb,
    T_SingleUseId3_Gb,
    T_SingleUseId4_Gb,
    T_SingleUseId9_Gb,
    T_SingleUseId9_Gb,
    T_SingleUseId8_Gb,
    T_SingleUseId9_Gb,
    T_SingleUseId8_Gb,
    T_SingleUseId9_Gb,
    T_SingleUseId3_Gb,
    T_SingleUseId4_Gb,
    T_SingleUseId14_Gb,
    T_SingleUseId15_Gb,
    T_SingleUseId16_Gb,
    T_SingleUseId17_Gb,
    T_SingleUseId18_Gb,
    T_SingleUseId19_Gb,
    T_SingleUseId20_Gb,
    T_SingleUseId21_Gb,
    T_SingleUseId22_Gb,
    T_SingleUseId24_Gb
};

