
#include <touchgfx/Font.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif

FONT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::GlyphNode glyphs_verdana_20_4bpp[] FONT_LOCATION_FLASH_ATTRIBUTE =
{
    {     0,  32,   0,   0,   0,   0,   7, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {     0,  39,   3,   6,  15,   1,   5, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {    12,  47,  10,  18,  15,  -1,   9, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   102,  48,  11,  14,  14,   1,  13, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   186,  63,   9,  14,  14,   1,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   256,  65,  14,  14,  14,   0,  14,   0,   3, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   354,  67,  13,  14,  14,   1,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   452,  70,  11,  14,  14,   1,  12, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   536,  72,  13,  14,  14,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   634,  77,  14,  14,  14,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   732,  78,  13,  14,  14,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   830,  79,  14,  14,  14,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   928,  84,  13,  14,  14,   0,  12,   3,   3, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1026,  97,  10,  11,  11,   1,  12,   6,   2, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1081, 101,  10,  11,  11,   1,  12,   8,   1, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1136, 105,   3,  14,  14,   1,   5, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1164, 108,   3,  15,  15,   1,   5, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1194, 109,  17,  11,  11,   1,  19, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1293, 110,  10,  11,  11,   1,  13, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1348, 111,  11,  11,  11,   1,  12,   9,   1, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1414, 112,  11,  15,  11,   1,  12, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1504, 114,   8,  11,  11,   1,   9,  10,   1, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1548, 116,   8,  14,  14,   0,   8, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1604, 117,  10,  11,  11,   1,  13,  11,   1, touchgfx::GLYPH_DATA_FORMAT_A4 | 0}
};

