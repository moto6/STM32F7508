#include <touchgfx/Font.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif

FONT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::KerningNode kerning_verdanab_21_4bpp[] FONT_LOCATION_FLASH_ATTRIBUTE =
{
    {0, 0}
};

