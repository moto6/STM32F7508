
#include <touchgfx/Font.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif

FONT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::GlyphNode glyphs_verdanab_21_4bpp[] FONT_LOCATION_FLASH_ATTRIBUTE =
{
    {     0,  32,   0,   0,   0,   0,   7, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {     0,  63,  11,  15,  15,   1,  13, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {    90,  67,  14,  15,  15,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   195,  69,  12,  15,  15,   1,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   285,  73,  10,  15,  15,   1,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   360,  77,  17,  15,  15,   1,  20, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   495,  84,  14,  15,  15,   0,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   600,  97,  13,  12,  12,   0,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   684, 101,  14,  12,  12,   0,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   768, 103,  13,  16,  12,   0,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   880, 105,   5,  16,  16,   1,   7, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   928, 107,  13,  16,  16,   1,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1040, 109,  20,  12,  12,   1,  22, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1160, 110,  13,  12,  12,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1244, 111,  14,  12,  12,   0,  14, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1328, 114,  10,  12,  12,   1,  10, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1388, 116,  10,  15,  15,   0,  10, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1463, 117,  13,  12,  12,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0}
};

