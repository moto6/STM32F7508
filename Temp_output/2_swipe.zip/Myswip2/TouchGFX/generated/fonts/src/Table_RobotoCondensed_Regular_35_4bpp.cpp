
#include <touchgfx/Font.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif

FONT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::GlyphNode glyphs_RobotoCondensed_Regular_35_4bpp[] FONT_LOCATION_FLASH_ATTRIBUTE =
{
    {     0,  32,   0,   0,   0,   0,   8, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {     0,  45,   8,   3,  12,   1,  10, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {    12,  46,   4,   4,   4,   2,   9, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {    20,  47,  12,  28,  25,   0,  12, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   188,  63,  14,  25,  25,   0,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   363,  68,  17,  25,  25,   2,  20, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   588,  70,  15,  25,  25,   2,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   788,  71,  18,  25,  25,   1,  20, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1013,  72,  17,  25,  25,   2,  21, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1238,  73,   5,  25,  25,   2,   9, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1313,  75,  18,  25,  25,   2,  19, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1538,  77,  21,  25,  25,   2,  25, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1813,  85,  16,  25,  25,   2,  20, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2013,  97,  14,  19,  19,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2146,  99,  14,  19,  19,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2279, 101,  14,  19,  19,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2412, 102,  11,  27,  27,   0,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2574, 105,   4,  27,  27,   2,   8, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2628, 109,  24,  19,  19,   1,  26, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2856, 110,  15,  19,  19,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3008, 111,  15,  19,  19,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3160, 114,  10,  19,  19,   1,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3255, 115,  13,  19,  19,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3388, 116,  10,  24,  24,   0,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3508, 117,  15,  19,  19,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3660, 118,  15,  19,  19,   0,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  3812, 121,  15,  26,  19,   0,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0}
};

