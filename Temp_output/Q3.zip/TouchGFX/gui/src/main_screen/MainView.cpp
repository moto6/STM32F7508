#include <gui/main_screen/MainView.hpp>
#include <BitmapDatabase.hpp>

MainView::MainView() :
    xAngle3D(0.0f),
    yAngle3D(0.0f),
    zAngle3D(0.0f),
    deltaXangle3D(0.032f),
    deltaYangle3D(0.029f),
    deltaZangle3D(0.027f),
    zAngle2D(0.0f),
    deltaZangle2D(0.019f)
{
}

void MainView::setupScreen()
{
    // Setup the texture mapper image that does 3D rotation
    textureMapperImage3D.setBitmap(Bitmap(BITMAP_IMAGE00_ID));

    // Extra space for the image to rotate in
    int borderWidth = 40;
    int borderHeight = 40;

    int imageWidth = textureMapperImage3D.getBitmap().getWidth();
    int imageHeight = textureMapperImage3D.getBitmap().getHeight();

    // Position the texture mapper image on the screen
    textureMapperImage3D.setXY(40, 40);

    // Set the width and height of the texture mapper image widget, including
    // space for the image to rotate (border)
    textureMapperImage3D.setWidth(imageWidth + borderWidth * 2);
    textureMapperImage3D.setHeight(imageHeight + borderHeight * 2);

    // Place the actual bitmap inside the texture mapper image.
    textureMapperImage3D.setBitmapPosition(borderWidth, borderHeight);

    // Set the camera distance which is the distance to the image in the z direction.
    // This has an effect of the perspective ratio of the image when it rotates
    textureMapperImage3D.setCameraDistance(300.0f);

    // Set the center of rotation of the texture mapper image (here it is the center of the image)
    textureMapperImage3D.setOrigo(textureMapperImage3D.getBitmapPositionX() + (imageWidth / 2), textureMapperImage3D.getBitmapPositionY() + (imageHeight / 2), textureMapperImage3D.getCameraDistance());

    // Place the camera/eye of the viewer relative the image (here it is the center of the image)
    textureMapperImage3D.setCamera(textureMapperImage3D.getBitmapPositionX() + (imageWidth / 2), textureMapperImage3D.getBitmapPositionY() + (imageHeight / 2));

    // Set the rendering algorithm. Here the fast lower image quality NEAREST_NEIGHBOR algorithm is chosen.
    // Another option is the slower but high image quality Bilinear Interpolation algorithm.
    textureMapperImage3D.setRenderingAlgorithm(TextureMapper::NEAREST_NEIGHBOR);

    // Setup the texture mapper image that does 2D rotation
    // Similar to the setup of the 3D rotating image above.
    textureMapperImage2D.setBitmap(Bitmap(BITMAP_IMAGE01_ID));

    imageWidth = textureMapperImage2D.getBitmap().getWidth();
    imageHeight = textureMapperImage2D.getBitmap().getHeight();

    textureMapperImage2D.setXY(240, 40);
    textureMapperImage2D.setWidth(imageWidth + borderWidth * 2);
    textureMapperImage2D.setHeight(imageHeight + borderHeight * 2);
    textureMapperImage2D.setBitmapPosition(borderWidth, borderHeight);
    textureMapperImage2D.setCameraDistance(300.0f);
    textureMapperImage2D.setOrigo(textureMapperImage2D.getBitmapPositionX() + (imageWidth / 2), textureMapperImage2D.getBitmapPositionY() + (imageHeight / 2), textureMapperImage2D.getCameraDistance());
    textureMapperImage2D.setCamera(textureMapperImage2D.getBitmapPositionX() + (imageWidth / 2), textureMapperImage2D.getBitmapPositionY() + (imageHeight / 2));
    textureMapperImage2D.setRenderingAlgorithm(TextureMapper::NEAREST_NEIGHBOR);

    add(textureMapperImage3D);
    add(textureMapperImage2D);
}

void MainView::tearDownScreen()
{
}

void MainView::handleTickEvent()
{
    // Update angle values
    xAngle3D += deltaXangle3D;
    yAngle3D += deltaYangle3D;
    zAngle3D += deltaZangle3D;

    zAngle2D += deltaZangle2D;

    // Update the images with the new angles
    // The image is automatically invalidated (the optimal minimal area).
    // If any of the set..() methods (e.g. setOrigo, setCamera, setRenderingAlgorithm...) are used
    // remember to manually invalidate the image afterwards (textureMapperImage2D.invalidate()).
    textureMapperImage3D.updateAngles(xAngle3D, yAngle3D, zAngle3D);
    textureMapperImage2D.updateAngles(0.0F, 0.0F, zAngle2D);
}
