
#include <touchgfx/Font.hpp>

#ifndef NO_USING_NAMESPACE_TOUCHGFX
using namespace touchgfx;
#endif

FONT_LOCATION_FLASH_PRAGMA
KEEP extern const touchgfx::GlyphNode glyphs_RobotoCondensed_Regular_35_4bpp[] FONT_LOCATION_FLASH_ATTRIBUTE =
{
    {     0,  32,   0,   0,   0,   0,   8, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {     0,  63,  14,  25,  25,   0,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   175,  67,  17,  25,  25,   1,  19, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   400,  83,  17,  25,  25,   1,  19, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   625,  97,  14,  19,  19,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   758,  99,  14,  19,  19,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {   891, 100,  14,  27,  27,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1080, 101,  14,  19,  19,   1,  16, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1213, 102,  11,  27,  27,   0,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1375, 104,  15,  27,  27,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1591, 105,   4,  27,  27,   2,   8, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1645, 108,   4,  27,  27,   2,   8, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1699, 110,  15,  19,  19,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  1851, 111,  15,  19,  19,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2003, 112,  15,  26,  19,   1,  17, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2211, 114,  10,  19,  19,   1,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2306, 115,  13,  19,  19,   1,  15, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2439, 116,  10,  24,  24,   0,  11, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0},
    {  2559, 119,  22,  19,  19,   0,  22, 255,   0, touchgfx::GLYPH_DATA_FORMAT_A4 | 0}
};

