************************************************************************************
* @file    readme.txt                                                              *
* @author  MCD Application Team                                                    *
* @version V3.1                                                                    *
* @date    18-May-2018                                                             *
* @brief   Boundary Scan Description Language(BSDL) files for the STM32F7 MCUs.    *                     
************************************************************************************
* COPYRIGHT(c) 2018 STMicroelectronics                                             * 
*                                                                                  *
* Redistribution and use in source and binary forms, with or without modification, *
* are permitted provided that the following conditions are met:                    *
*   1. Redistributions of source code must retain the above copyright notice,      *
*      this list of conditions and the following disclaimer.                       *
*   2. Redistributions in binary form must reproduce the above copyright notice,   *
*      this list of conditions and the following disclaimer in the documentation   *
*      and/or other materials provided with the distribution.                      *
*   3. Neither the name of STMicroelectronics nor the names of its contributors    *
*      may be used to endorse or promote products derived from this software       *
*      without specific prior written permission.                                  *
*                                                                                  *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"      *
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE        *
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE   *
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE     *
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL       *
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR       *
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER       *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,    *
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE    *
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.             *
************************************************************************************

=======================
How to use BSDL Files :
=======================

The STM32F7 MCUs integrate two serially connected JTAG TAPs, the boundary scan
TAP (IR is 5-bit wide) and the CortexMx TAP (IR is 4-bit wide).

The package contains :

   + A BSDL File for the CortexMx TAP and is common to all STM32F7 devices
   + Boundary scan BSDL Files for each STM32F745_746_756 device on different packages :
   
	  o LQFP208
	  o LQFP176
	  o LQFP144
	  o LQFP100
	  o TFBGA216
	  o UFBGA176
	  o TFBGA100
	  o WLCSP143

   + Boundary scan BSDL Files for each STM32F765_767_777 device on different packages :
   
	  o LQFP208
	  o LQFP176
	  o LQFP144
	  o LQFP100
	  o TFBGA216
	  o UFBGA176
	  o TFBGA100
	 
   + Boundary scan BSDL Files for each STM32F768A_769_778A_779 device on different packages :
   
	  o LQFP208
	  o LQFP176
	  o TFBGA216
	  o WLCSP180

   + Boundary scan BSDL Files for each STM32F7x2 device on different packages :
   
	  o LQFP176
	  o LQFP144
	  o LQFP100
	  o LQFP64
	  o UFBGA176

   + Boundary scan BSDL Files for each STM32F7x3 device on different packages :
   
	  o LQFP176
	  o LQFP144
	  o UFBGA176
	  o UFBGA144
	  o WLCSP100

In order to run boundary scan, always provide two BSDL files to your JTAG Boundary scan tool:
the "CortexMx.bsd" and your selected "STM32Fxx_device_Package.bsd".  

WARNING : Do not combine both BSDL files in a single TAP with 9-bit wide !

For more details on the internal TAPs description refer to the Reference Manual
of the selected STM32xxxx device , Section : JTAG TAP connection.


==========================
* V3.1 - 18 May 2018
==========================

New Features
************
    + Adding BSDL file for STM32F745_F746_F756_TFBGA100 device
    + Adding BSDL file for STM32F765_767_777_TFBGA100 device
	
==========================
* V3.0 - 26 January 2017
==========================

New Features
************
    + Adding BSDL files for STM32F7x2 devices
    + Adding BSDL files for STM32F7x3 devices
======================
* V2.0 - 29 March 2016
======================

New Features
************
    + Adding BSDL files for STM32F765_767_777 devices
    + Adding BSDL files for STM32F768A_769_778A_779 devices
   
========================
* V1.0 - 28-August-2015 
========================
  Created with BSDL files for STM32F745_746_756 devices
  

******************* (C) COPYRIGHT 2016 STMicroelectronics *****END OF FILE
